for count in range(1, 1001):
	if count % 2 != 0:
		print count